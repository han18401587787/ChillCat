# 绪安 APP · MVP 设计稿 v2（匹配代码实现）

> Ardot 在线设计文件：https://ardot.tencent.com/file/693784021067696

## 设计系统（来源：CCAppTheme.swift）

| 类别 | 值 |
|------|-----|
| 主色 Primary | `#5A7A8A` (蓝灰) |
| 背景 Background | `#F9F6F2` (暖白) |
| 表面 Surface | `#F0EDE8` (浅米灰) |
| 卡片 CardBg | `#FFFFFF` |
| 主文字 | `#2D2D2D` |
| 次要文字 | `#7A7A7A` |
| 浅文字 | `#AAAAAA` |
| 字体 | SF Pro (系统字体) |
| 圆角 | 8 / 12 / 16 / 24 |
| 间距 | 6 / 10 / 16 / 24 / 32 |

## 情绪色板（CCEmotion.swift）

| 情绪 | 色值 |
|------|------|
| 平静 | `#66BB6A` softGreen |
| 开心 | `#C9A063` warmLight |
| 疲惫 | `#B8D4E3` primaryMuted |
| 焦虑 | `#D4C8E8` softPurple |
| 委屈 | `#E8B8C8` softPink |
| 孤独 | `#7A9AAA` primaryLight |
| 烦躁 | `#E57373` error |
| 迷茫 | `#E8D9F0` softPurpleLight |
| 易怒 | `#8B6F47` warm |
| 内耗 | `#AAAAAA` textMuted |

## Tab 结构（CCMainTabView）

| Tab | 图标 | 视图 |
|-----|------|------|
| 首页 | house.fill | CCHomeView |
| 共鸣 | heart.fill | CCTreeHoleView |
| 会员 | crown.fill | CCMemberCenterView |
| 我的 | person.fill | CCProfileView |

## 页面清单（v2 匹配代码）

| PNG | 页面 | 对应代码 |
|-----|------|----------|
| `4_1.png` | 01-Welcome 欢迎页 | CCWelcomeView.swift |
| `4_14.png` | 02-Login 登录页 | CCLoginView.swift |
| `4_32.png` | 03-Home 首页 | CCHomeView.swift |
| `4_128.png` | 04-Resonance 共鸣墙 | CCTreeHoleView.swift |
| `4_169.png` | 05-VIP 会员中心 | CCMemberCenterView.swift |
| `4_200.png` | 06-Profile 个人中心 | CCProfileView.swift |

## v1 vs v2 主要差异

| 维度 | v1 (Figma 规范) | v2 (代码实现) |
|------|----------------|---------------|
| 主色 | `#B8D4E3` | `#5A7A8A` |
| 背景 | `#FAF8F5` | `#F9F6F2` |
| Tab 数量 | 5 (首页/治愈/共鸣/成长/我的) | 4 (首页/共鸣/会员/我的) |
| 登录方式 | 手机号+验证码+社交 | 用户名+密码表单 |
| 首页结构 | 情绪打卡+树洞 | 情绪网格+AI倾听+任务+回顾+探索 |
| 治愈模块 | 单独 Tab | 已整合到首页探索区域 |
| 新增页面 | - | 会员中心 |
| 字体 | PingFang SC | SF Pro (系统字体) |
| 图标 | Emoji | SF Symbols + Emoji |
| 框架 | - | SwiftUI (iOS 17+) |
